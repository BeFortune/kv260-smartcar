// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XFFN_ACCEL_H
#define XFFN_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xffn_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XFfn_accel_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XFfn_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFfn_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFfn_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFfn_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFfn_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XFfn_accel_Initialize(XFfn_accel *InstancePtr, UINTPTR BaseAddress);
XFfn_accel_Config* XFfn_accel_LookupConfig(UINTPTR BaseAddress);
#else
int XFfn_accel_Initialize(XFfn_accel *InstancePtr, u16 DeviceId);
XFfn_accel_Config* XFfn_accel_LookupConfig(u16 DeviceId);
#endif
int XFfn_accel_CfgInitialize(XFfn_accel *InstancePtr, XFfn_accel_Config *ConfigPtr);
#else
int XFfn_accel_Initialize(XFfn_accel *InstancePtr, const char* InstanceName);
int XFfn_accel_Release(XFfn_accel *InstancePtr);
#endif

void XFfn_accel_Start(XFfn_accel *InstancePtr);
u32 XFfn_accel_IsDone(XFfn_accel *InstancePtr);
u32 XFfn_accel_IsIdle(XFfn_accel *InstancePtr);
u32 XFfn_accel_IsReady(XFfn_accel *InstancePtr);
void XFfn_accel_EnableAutoRestart(XFfn_accel *InstancePtr);
void XFfn_accel_DisableAutoRestart(XFfn_accel *InstancePtr);

void XFfn_accel_Set_x(XFfn_accel *InstancePtr, u64 Data);
u64 XFfn_accel_Get_x(XFfn_accel *InstancePtr);
void XFfn_accel_Set_y(XFfn_accel *InstancePtr, u64 Data);
u64 XFfn_accel_Get_y(XFfn_accel *InstancePtr);
void XFfn_accel_Set_w1(XFfn_accel *InstancePtr, u64 Data);
u64 XFfn_accel_Get_w1(XFfn_accel *InstancePtr);
void XFfn_accel_Set_b1(XFfn_accel *InstancePtr, u64 Data);
u64 XFfn_accel_Get_b1(XFfn_accel *InstancePtr);
void XFfn_accel_Set_w2(XFfn_accel *InstancePtr, u64 Data);
u64 XFfn_accel_Get_w2(XFfn_accel *InstancePtr);
void XFfn_accel_Set_b2(XFfn_accel *InstancePtr, u64 Data);
u64 XFfn_accel_Get_b2(XFfn_accel *InstancePtr);
void XFfn_accel_Set_num_tokens(XFfn_accel *InstancePtr, u32 Data);
u32 XFfn_accel_Get_num_tokens(XFfn_accel *InstancePtr);

void XFfn_accel_InterruptGlobalEnable(XFfn_accel *InstancePtr);
void XFfn_accel_InterruptGlobalDisable(XFfn_accel *InstancePtr);
void XFfn_accel_InterruptEnable(XFfn_accel *InstancePtr, u32 Mask);
void XFfn_accel_InterruptDisable(XFfn_accel *InstancePtr, u32 Mask);
void XFfn_accel_InterruptClear(XFfn_accel *InstancePtr, u32 Mask);
u32 XFfn_accel_InterruptGetEnabled(XFfn_accel *InstancePtr);
u32 XFfn_accel_InterruptGetStatus(XFfn_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
