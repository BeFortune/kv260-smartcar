// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xffn_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFfn_accel_CfgInitialize(XFfn_accel *InstancePtr, XFfn_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFfn_accel_Start(XFfn_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFfn_accel_IsDone(XFfn_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFfn_accel_IsIdle(XFfn_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFfn_accel_IsReady(XFfn_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFfn_accel_EnableAutoRestart(XFfn_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFfn_accel_DisableAutoRestart(XFfn_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XFfn_accel_Set_x(XFfn_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_X_DATA, (u32)(Data));
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XFfn_accel_Get_x(XFfn_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_X_DATA);
    Data += (u64)XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XFfn_accel_Set_y(XFfn_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_Y_DATA, (u32)(Data));
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XFfn_accel_Get_y(XFfn_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_Y_DATA);
    Data += (u64)XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XFfn_accel_Set_w1(XFfn_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W1_DATA, (u32)(Data));
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W1_DATA + 4, (u32)(Data >> 32));
}

u64 XFfn_accel_Get_w1(XFfn_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W1_DATA);
    Data += (u64)XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W1_DATA + 4) << 32;
    return Data;
}

void XFfn_accel_Set_b1(XFfn_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B1_DATA, (u32)(Data));
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B1_DATA + 4, (u32)(Data >> 32));
}

u64 XFfn_accel_Get_b1(XFfn_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B1_DATA);
    Data += (u64)XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B1_DATA + 4) << 32;
    return Data;
}

void XFfn_accel_Set_w2(XFfn_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W2_DATA, (u32)(Data));
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W2_DATA + 4, (u32)(Data >> 32));
}

u64 XFfn_accel_Get_w2(XFfn_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W2_DATA);
    Data += (u64)XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_W2_DATA + 4) << 32;
    return Data;
}

void XFfn_accel_Set_b2(XFfn_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B2_DATA, (u32)(Data));
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B2_DATA + 4, (u32)(Data >> 32));
}

u64 XFfn_accel_Get_b2(XFfn_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B2_DATA);
    Data += (u64)XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_B2_DATA + 4) << 32;
    return Data;
}

void XFfn_accel_Set_num_tokens(XFfn_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_NUM_TOKENS_DATA, Data);
}

u32 XFfn_accel_Get_num_tokens(XFfn_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_NUM_TOKENS_DATA);
    return Data;
}

void XFfn_accel_InterruptGlobalEnable(XFfn_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_GIE, 1);
}

void XFfn_accel_InterruptGlobalDisable(XFfn_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_GIE, 0);
}

void XFfn_accel_InterruptEnable(XFfn_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_IER);
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_IER, Register | Mask);
}

void XFfn_accel_InterruptDisable(XFfn_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_IER);
    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFfn_accel_InterruptClear(XFfn_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFfn_accel_WriteReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_ISR, Mask);
}

u32 XFfn_accel_InterruptGetEnabled(XFfn_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_IER);
}

u32 XFfn_accel_InterruptGetStatus(XFfn_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFfn_accel_ReadReg(InstancePtr->Control_BaseAddress, XFFN_ACCEL_CONTROL_ADDR_ISR);
}

