# PYNQ FFN 迁移包

**已完成离线 PS 迁移和主机数值验证；没有宣称板上部署、真实 PL 加速或实车验收完成。**

面向现有资料中的 **KV260/K26**：原模型拆成五段 CPU ONNX 子图，四个 `128→256→128`、erf-GELU FFN 通过统一后端接口替换。Attention、LayerNorm、残差、预处理和输出头留在 PS。原工程保持不变。

本次已用原载荷的 **173 组三摄数据**完成三种模式逐帧数值对照，另有 **48 项软件测试**在两套依赖环境通过。详情和硬件验收边界见验证记录。

## 阅读顺序

1. [文件分析与迁移决策](docs/01_文件分析与迁移决策.md)：目录、模型、数据、历史板端状态、ROS风险与范围。
2. [FFN 接口与流水线设计](docs/02_FFN接口与流水线设计.md)：四层边界、AXI与寄存器、缓存/超时、流水线优化。
3. [AMD 与 Ross 从零操作指南](docs/03_AMD与Ross从零操作指南.md)：安装与许可、PS部署、HLS、Vivado、PYNQ、Ross。
4. [验证记录](docs/04_验证记录.md)：真实命令、测试、误差、未完成硬件验收。
5. [逐步 Notebook](notebooks/01_ps_to_pl.ipynb)：默认只跑 CPU，PL 下载需要显式启用。
6. [独立交付包说明](DELIVERY.md)：ZIP内容、哈希清单，以及缺少原载荷时的复现边界。

## 最快跑通（不用板卡）

在本目录打开 PowerShell，使用 Python 3.10～3.12。下面以 Windows Python 3.12 为例：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
.\.venv\Scripts\python.exe -m pytest tests -q

.\.venv\Scripts\python.exe tools\validate_split.py `
  --bundle artifacts\bundle_20261014 `
  --recording artifacts\sample_recording_1779374497 `
  --random-cases 3 `
  --output artifacts\my_validation.json

.\.venv\Scripts\python.exe -m ps.replay `
  --bundle artifacts\bundle_20261014 `
  --recording artifacts\sample_recording_1779374497 `
  --backend split-ort --threads 4 `
  --output-dir artifacts\my_replay
```

这些输出路径必须尚不存在；重跑换新名字。样本只有一组三摄，用于快速连通和等价检验，不是驾驶准确率测试集。

本轮48项测试是在相邻 `kv260_v1/v1_payload.zip` 和历史 `first_input.npy` 都存在时通过的，**没有skip**。如果只复制本目录或使用独立交付ZIP，依赖原载荷的集成测试会明确skip，不能称为复现48项全覆盖；已附bundle与样本仍可直接用于 `validate_split.py` 和 `ps.replay`。

本次已经生成 bundle，也可以从原 payload 重建：

```powershell
.\.venv\Scripts\python.exe tools\prepare_model.py `
  --payload ..\kv260_v1\v1_payload.zip `
  --output-dir artifacts\my_bundle
```

准备脚本只读取指定成员 `model/model_current.onnx`，核验固定 SHA-256：

```text
ad58d1fc9168da94b9ce076ba8cc9754c371ead87974da8bc9cc601ad1650d5b
```

新训练模型需要重新审查切图，不提供跳过此检查的开关。bundle 所有文件均有哈希清单；运行时拒绝被修改或混搭的成员。

## 三种 CPU 模式与 PL 注入

| 模式 | 实际执行 |
|---|---|
| `golden` | 原始完整模型，CPU ORT |
| `split-ort` | 五段 PS + 四段 FFN，全部 CPU ORT；用于检查切图 |
| `split-numpy` | 五段 PS 用 CPU ORT，FFN 用 exact-erf NumPy；用于检查后端合同 |

```python
from ps.runtime import Runtime

runner = Runtime("artifacts/bundle_20261014", mode="split-ort", threads=4)
outputs = runner.run(images)  # float32 [1,3,3,66,200]
print(outputs["speed_raw"])  # [1,2]，不要再乘300/500
print(runner.last_timings_ms)
```

四输出均保留：`speed_norm`、`speed_raw`、`region_logits`、`region_probs`。区域输出一致不等于该头具有经验证的分类准确率。

PL 对接是 `Runtime(..., mode="split-numpy", backend=pynq_backend)`；模式名表示可替换路径，**只有显式注入 `PynqFFN` 才访问 PL**。该后端接收已经由调用者明确加载的 IP，不自行下载 Overlay。详细示例与板前提见教程/Notebook；请勿把演示路径或实例名当成已探测结果。

## 代码地图

```text
ps/
  partition.py       固定模型边界/拓扑验证、五段PS与四段FFN导出
  runtime.py         CPU整图/分图、live tensor调度、后端注入
  backends.py        NumPy exact-erf FFN
  preprocess.py      原NUC一致的三摄预处理和文件读取
  replay.py          离线录制推理，仅写结果文件
  pynq_backend.py    AXI-Lite、64位地址、缓存同步、超时隔离

tools/
  prepare_model.py   生成新bundle
  validate_split.py  最终四输出、整数轮速、四FFN切点严格对照
  validate_cpp.py    主机C++参考核与真实权重对照，不是PL
  validate_payload.py 直接读原ZIP完成173组三摄全量等价验证
  board_preflight.py 只读本机环境，不导入PYNQ/不装载硬件

hls/
  ffn_accel.cpp/.hpp 浮点FFN正确性参考核，不是已优化的实时流水线
  testbench.cpp     边界/尾token/权重重载/独立double参考
  build_hls.tcl     传统HLS入口，须给真实FPGA_PART
  make_config.py    现代2026.1 cfg生成，已核实64位地址键；构建受许可阻塞
  host_bridge.cpp  主机验证专用；不要加入HLS综合
```

`hls/build/*.exe/*.dll` 是 Windows 主机测试产物，不是 FPGA bitstream，也不能复制到 ARM 当板端程序执行。普通运行时不加载这些文件。

## 当前关键限制

- 新包尚未复制到板端运行；没有使用历史日志中的凭据登录板卡。
- 历史证据截至 2026-10-12 仍显示 CMA 预留失败，没有成功的完整 Overlay/PL 验收；今天状态未现场复核。
- 本机已找到AMD 2026.1安装并尝试实际工具；Vivado启动exit42（无有效许可），HLS C simulation和compile均退出码1，在part/许可初始化阶段失败，未执行testbench或生成RTL。没有 `.bit/.hwh`，没有成功综合/RTL cosim/时序/资源/FPS报告。
- 本机头文件/schema已核实 `hls::erff` 和64位AXI配置键，但整核HLS编译仍未通过；不能把配置生成成功当成硬件验收。
- NumPy FFN 是正确性替身，可能更慢；PS分图也有额外开销，不能根据功能正确就承诺加速。
- 不包含实时相机同步、ROS ARM重建或底盘串口控制；原车控有已记录安全问题，不能原样直接启动。
- Overlay下载、CMA/boot修改、重启、刷固件及车辆动作均未发生，不属于本包默认操作。

项目资料中的实际目标仍需确认：板卡是否保持KV260、当前系统/启动内存状态、AMD安装/许可条件，以及最终允许误差/帧率门槛。基础软件可以在这些确认之前离线运行；硬件验收不能省略它们。
